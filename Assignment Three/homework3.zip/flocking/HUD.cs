using Godot;
using System;

public partial class HUD : Control
{
	[Signal] public delegate void StartGameEventHandler();
	[Signal] public delegate void TryAgainEventHandler();

	private Button _startButton;
	private Button _tryAgainButton;

	public override void _Ready()
	{
		_startButton = GetNode<Button>("VBoxContainer/StartButton");
		_tryAgainButton = GetNode<Button>("VBoxContainer/TryAgainButton");

		_startButton.Pressed += OnStartPressed;
		_tryAgainButton.Pressed += OnTryAgainPressed;

		_tryAgainButton.Hide(); // Initially hide Try Again
	}

	private void OnStartPressed()
	{
		Hide(); // hide HUD when game starts
		EmitSignal("StartGameEventHandler"); // 🔹 use string name
	}

	private void OnTryAgainPressed()
	{
		Hide(); // hide HUD when retrying
		EmitSignal("TryAgainEventHandler"); // 🔹 use string name
	}

	public void ShowTryAgain()
	{
		Show();
		_tryAgainButton.Show();
		_startButton.Hide();
	}
}
