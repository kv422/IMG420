using Godot;
using System;

public partial class Target : RigidBody2D
{
	[Export] public float MoveForce = 600f;
	[Export] public float MaxSpeed = 300f;

	public override void _Ready()
	{
		GravityScale = 0; // stop falling
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 inputDirection = Vector2.Zero;

		if (Input.IsActionPressed("ui_right"))
			inputDirection.X += 1;
		if (Input.IsActionPressed("ui_left"))
			inputDirection.X -= 1;
		if (Input.IsActionPressed("ui_down"))
			inputDirection.Y += 1;
		if (Input.IsActionPressed("ui_up"))
			inputDirection.Y -= 1;

		inputDirection = inputDirection.Normalized();

		// Directly set velocity based on input
		LinearVelocity = inputDirection * MaxSpeed;
	}
}
