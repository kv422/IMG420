using Godot;
using System;

public partial class Explosion : Node2D
{
	[Export] public float Duration = 1.0f;  
	[Export] public float MaxScale = 1.0f;

	private float _timer = 0f;

	public override void _Ready()
	{
		Scale = new Vector2(0.1f, 0.1f);
		GetTree().CreateTimer(Duration).Timeout += QueueFree;
	}

	public override void _Process(double delta)
	{
		_timer += (float)delta;
		float t = Math.Min(_timer / Duration, 1.0f);
		Scale = new Vector2(0.1f + t * (MaxScale - 0.1f), 0.1f + t * (MaxScale - 0.1f));
	}
}
