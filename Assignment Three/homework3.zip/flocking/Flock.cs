using Godot;
using System;

//processes multiple scenes and kinda refers to them and does stuff

public partial class Flock : Node2D
{
	//able to edit the amount of boids from the inspector on the right
	[Export] public int NumberOfBoids = 10;
	
	//telling that we have access to this scene (a)
	[Export] public PackedScene BoidScene;
	

	public override void _Ready()
	{
		if (BoidScene == null)
		{
			GD.PrintErr("BoidScene not set.");
			return;
		}

		for (int i = 0; i < NumberOfBoids; i++)
		{
			SpawnBoid();
		}
	}

	private void SpawnBoid()
	{
		//(a) after referencing (a) references node in instanatiate and then creates them using the add
		Boid boid = BoidScene.Instantiate<Boid>();
		
		//refrenes target and only references it once bc only one named node target 
		boid.SetTarget(GetNode<RigidBody2D>("Target"));
		AddChild(boid);
	}
}
