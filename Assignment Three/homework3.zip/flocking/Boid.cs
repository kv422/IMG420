/*using Godot;
using System.Collections.Generic;

public partial class Boid : CharacterBody2D
{
	// Adjustable in the Inspector
	[Export] public float MaxSpeed = 100f;
	[Export] public float SeparationWeight = 3.5f;
	[Export] public float AlignmentWeight = 1.0f;
	[Export] public float CohesionWeight = 0.5f;
	[Export] public float FollowWeight = 50.0f;
	[Export] public float FollowRadius = 30.0f;
	private List<Boid> _neighbors = new();
	private Area2D _detectionArea;
	private RigidBody2D _target;
	
	
	public override void _Ready()
	{
		_detectionArea = GetNode<Area2D>("DetectionArea");
		_detectionArea.BodyEntered += OnBodyEntered;
		_detectionArea.BodyExited += OnBodyExited;
		
		// setting positions based on given vierport
		var viewportRect = GetViewportRect();
		var randomX = GD.Randf() * viewportRect.Size.X;
		var randomY = GD.Randf() * viewportRect.Size.Y;
		Position = new Vector2(randomX, randomY);
		
		
		// setting random direction of boid
		var randomAngle = GD.Randf() * Mathf.Pi * 2;
		var randomVelocity = new Vector2(Mathf.Cos(randomAngle), Mathf.Sin(randomAngle)) * MaxSpeed;
		Velocity = randomVelocity;
		MoveAndSlide();
		
		// Optional: Make boid face its direction of movement
		// orients to boid to where the boid or shape is pointing 
		LookAt(Position + Velocity);
	}
	public void SetTarget(RigidBody2D Target)
	{
		_target = Target;
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 separationVector = Separation() * SeparationWeight;
		
		Vector2 alignmentVector = Alignment() * AlignmentWeight;
		Vector2 cohesionVector = Cohesion() * CohesionWeight;
		Vector2 followVector = Centralization() * FollowWeight;
		
		
		//GD.Print($"The value of my variable is: {followVector}");
		Velocity += (separationVector + alignmentVector + cohesionVector + followVector) * (float)delta;
		
		// Clamp velocity to prevent boids from moving too fast
		Velocity = Velocity.LimitLength(MaxSpeed);
		//GD.Print($"The value of my variable is: {Velocity}");
		MoveAndSlide();
		
		// Optional: Make boid face its direction of movement
		LookAt(Position + Velocity);
	}



//////on body enter and exit kinda add boids to list if they enter the space. use of signals is the circle shape ind detection area 
	private void OnBodyEntered(Node2D body)
	{	
		//check if the body is you to not add to list 
		if (body is Boid boid && body != this)
		{
			_neighbors.Add(boid);
		}
	}

	private void OnBodyExited(Node2D body)
	{
		if (body is Boid boid && body != this)
		{
			_neighbors.Remove(boid);
		}
	}

	// Rule 1: Separation—Avoid crowding neighbors
	private Vector2 Separation()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;

		Vector2 steer = Vector2.Zero;
		foreach (var neighbor in _neighbors)
		{
			Vector2 diff = Position - neighbor.Position;
			steer += diff.Normalized() / diff.Length();
		}
		//GD.Print($"The value of my variable is: {steer}");
		return steer.Normalized();
	}

	// Rule 2: Alignment—Steer towards the average heading of neighbors
	private Vector2 Alignment()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;

		Vector2 averageVelocity = Vector2.Zero;
		foreach (var neighbor in _neighbors)
		{
			averageVelocity += neighbor.Velocity;
		}
		averageVelocity /= _neighbors.Count;
		return averageVelocity.Normalized();
	}

	// Rule 3: Cohesion—Move towards the average position of neighbors
	private Vector2 Cohesion()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;

		Vector2 centerOfMass = Vector2.Zero;
		foreach (var neighbor in _neighbors)
		{
			centerOfMass += neighbor.Position;
		}
		centerOfMass /= _neighbors.Count;

		Vector2 directionToCenter = centerOfMass - Position;
		return directionToCenter.Normalized();
	}
	
	private Vector2 Centralization()
	{
		if(_target != null)
		{
			////GD.Print($"The value of my variable is: {_target.GetPosition()}");
			////GD.Print($"The value of my variable is: {Position}");
			if (Position.DistanceTo(_target.GetPosition()) < FollowRadius)
			{
				return Vector2.Zero;
			}
			else
			{
				return ((_target.GetPosition() - Position).Normalized());
			}
		}
		else
		{
			return Vector2.Zero;
		}
		
	}
	private void BoidExitedScreen()
	{
		//GD.Print("Got here");
		Velocity *= -1;
		MoveAndSlide();
		
		// Optional: Make boid face its direction of movement
		LookAt(Position + Velocity);
	}
}
*/

using Godot;
using System.Collections.Generic;

public partial class Boid : CharacterBody2D
{
	[Export] public float MaxSpeed = 100f;
	[Export] public float SeparationWeight = 3.5f;
	[Export] public float AlignmentWeight = 1.0f;
	[Export] public float CohesionWeight = 0.5f;
	[Export] public float FollowWeight = 50.0f;
	[Export] public float FollowRadius = 30.0f;
	[Export] public PackedScene ExplosionScene;

	private List<Boid> _neighbors = new();
	private Area2D _detectionArea;
	private Area2D _hitbox;  // detects target collision
	private RigidBody2D _target;

	public override void _Ready()
	{
		_detectionArea = GetNode<Area2D>("DetectionArea");
		_detectionArea.BodyEntered += OnBodyEntered;
		_detectionArea.BodyExited += OnBodyExited;

		_hitbox = GetNodeOrNull<Area2D>("Hitbox");
		if (_hitbox != null)
			_hitbox.BodyEntered += OnHitboxBodyEntered;

		// Randomize start position
		var viewportRect = GetViewportRect();
		var randomX = GD.Randf() * viewportRect.Size.X;
		var randomY = GD.Randf() * viewportRect.Size.Y;
		Position = new Vector2(randomX, randomY);

		// Randomize initial direction
		var randomAngle = GD.Randf() * Mathf.Pi * 2;
		Velocity = new Vector2(Mathf.Cos(randomAngle), Mathf.Sin(randomAngle)) * MaxSpeed;

		MoveAndSlide();
		LookAt(Position + Velocity);
	}

	public void SetTarget(RigidBody2D target)
	{
		_target = target;
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 separationVector = Separation() * SeparationWeight;
		Vector2 alignmentVector = Alignment() * AlignmentWeight;
		Vector2 cohesionVector = Cohesion() * CohesionWeight;
		Vector2 followVector = Centralization() * FollowWeight;

		Velocity += (separationVector + alignmentVector + cohesionVector + followVector) * (float)delta;
		Velocity = Velocity.LimitLength(MaxSpeed);

		MoveAndSlide();
		LookAt(Position + Velocity);
	}

	// 🧨 when Boid collides with Target
	private void OnHitboxBodyEntered(Node2D body)
	{
		if (body is Target)
		{
			// Spawn explosion
			if (ExplosionScene != null)
			{
				Node2D explosion = ExplosionScene.Instantiate<Node2D>();
				explosion.GlobalPosition = GlobalPosition;
				GetTree().CurrentScene.AddChild(explosion);
			}

			// Optional: remove boid
			QueueFree();
		}
	}

	private void OnBodyEntered(Node2D body)
	{
		if (body is Boid boid && body != this)
			_neighbors.Add(boid);
	}

	private void OnBodyExited(Node2D body)
	{
		if (body is Boid boid && body != this)
			_neighbors.Remove(boid);
	}

	private Vector2 Separation()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;
		Vector2 steer = Vector2.Zero;
		foreach (var neighbor in _neighbors)
		{
			Vector2 diff = Position - neighbor.Position;
			steer += diff.Normalized() / diff.Length();
		}
		return steer.Normalized();
	}

	private Vector2 Alignment()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;
		Vector2 averageVelocity = Vector2.Zero;
		foreach (var neighbor in _neighbors)
			averageVelocity += neighbor.Velocity;
		averageVelocity /= _neighbors.Count;
		return averageVelocity.Normalized();
	}

	private Vector2 Cohesion()
	{
		if (_neighbors.Count == 0) return Vector2.Zero;
		Vector2 centerOfMass = Vector2.Zero;
		foreach (var neighbor in _neighbors)
			centerOfMass += neighbor.Position;
		centerOfMass /= _neighbors.Count;
		return (centerOfMass - Position).Normalized();
	}

	private Vector2 Centralization()
	{
		if (_target == null)
			return Vector2.Zero;

		if (Position.DistanceTo(_target.Position) < FollowRadius)
			return Vector2.Zero;

		return (_target.Position - Position).Normalized();
	}

	private void BoidExitedScreen()
	{
		Velocity *= -1;
		MoveAndSlide();
		LookAt(Position + Velocity);
	}
}
